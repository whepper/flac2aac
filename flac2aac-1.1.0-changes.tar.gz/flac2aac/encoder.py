"""Audio encoding module using FFmpeg and libfdk_aac.

Handles FLAC to AAC conversion at configurable VBR quality.
"""

import logging
import subprocess
from pathlib import Path

from config import Config

logger = logging.getLogger(__name__)


# Generous per-file encoding timeout (seconds). A 10-minute track at
# VBR 5 takes ~15s on modern hardware; 10 minutes is enough headroom
# for very long files on slow machines while still killing true hangs.
ENCODE_TIMEOUT_SECONDS = 600


class EncodingError(Exception):
    """Exception raised when encoding fails."""
    pass


class Encoder:
    """FFmpeg wrapper for FLAC to AAC encoding."""

    def __init__(self, config: Config):
        """Initialize encoder.

        Args:
            config: Application configuration
        """
        self.config = config
        self.ffmpeg_bin = config.paths.ffmpeg_bin
        self.vbr_quality = config.encoding.vbr_quality

    def encode(self, source: Path, destination: Path) -> None:
        """Encode a FLAC file to AAC.

        Args:
            source: Input FLAC file path
            destination: Output M4A file path

        Raises:
            EncodingError: If encoding fails
        """
        # Create output directory if needed
        destination.parent.mkdir(parents=True, exist_ok=True)

        # Build FFmpeg command.
        #
        # -hide_banner / -loglevel error: cut noise in stderr
        # -map 0:a            : take audio only (skip embedded cover)
        # -map_metadata -1    : drop all source metadata; mutagen writes it
        # -c:a libfdk_aac     : FDK-AAC encoder
        # -profile:a aac_low  : required for VBR
        # -vbr N              : quality 1-5 (5 = highest)
        # -y                  : overwrite destination
        cmd = [
            self.ffmpeg_bin,
            "-hide_banner",
            "-loglevel", "error",
            "-i", str(source),
            "-map", "0:a",
            "-map_metadata", "-1",
            "-c:a", "libfdk_aac",
            "-profile:a", "aac_low",
            "-vbr", str(self.vbr_quality),
            "-y",
            str(destination),
        ]

        logger.debug(f"Encoding: {source.name} -> {destination.name}")
        logger.debug(f"Command: {' '.join(cmd)}")

        try:
            subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True,
                timeout=ENCODE_TIMEOUT_SECONDS,
            )
            logger.info(f"Encoded: {source.name}")

        except subprocess.CalledProcessError as e:
            # Trim stderr to keep log output manageable on corrupt files
            stderr = (e.stderr or "").strip()
            if len(stderr) > 1000:
                stderr = stderr[:1000] + "... [truncated]"
            error_msg = f"Failed to encode {source.name}: {stderr}"
            logger.error(error_msg)
            raise EncodingError(error_msg) from e

        except subprocess.TimeoutExpired as e:
            error_msg = (
                f"FFmpeg timed out after {ENCODE_TIMEOUT_SECONDS}s while "
                f"encoding {source.name}"
            )
            logger.error(error_msg)
            raise EncodingError(error_msg) from e

        except FileNotFoundError:
            error_msg = f"FFmpeg binary not found: {self.ffmpeg_bin}"
            logger.error(error_msg)
            raise EncodingError(error_msg)

    def verify_ffmpeg(self) -> bool:
        """Verify FFmpeg is available and libfdk_aac is a working encoder.

        Uses ``ffmpeg -h encoder=libfdk_aac`` which explicitly probes the
        encoder. If libfdk_aac is missing, FFmpeg writes a line like
        "Codec 'libfdk_aac' is not recognized by FFmpeg." to stderr and
        exits 0 — so we must check both streams for the encoder header.
        """
        try:
            result = subprocess.run(
                [
                    self.ffmpeg_bin,
                    "-hide_banner",
                    "-h", "encoder=libfdk_aac",
                ],
                capture_output=True,
                text=True,
                check=False,
                timeout=10,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            logger.error(f"FFmpeg not usable at '{self.ffmpeg_bin}': {exc}")
            return False

        combined = (result.stdout or "") + (result.stderr or "")

        if "Encoder libfdk_aac" in combined:
            return True

        logger.error(
            "FFmpeg is installed but libfdk_aac is not available. "
            "Please install an FFmpeg build with --enable-libfdk-aac."
        )
        return False
