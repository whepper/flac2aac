"""Tests for scanner.py file discovery and path mapping."""

import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from scanner import Scanner


def _make_config(input_dir: Path, output_dir: Path) -> MagicMock:
    cfg = MagicMock()
    cfg.paths.input_dir = input_dir
    cfg.paths.output_dir = output_dir
    cfg.encoding.output_format = "m4a"
    cfg.processing.overwrite_existing = False
    return cfg


class TestScanner(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.input_dir = Path(self.tmpdir) / "in"
        self.output_dir = Path(self.tmpdir) / "out"
        self.input_dir.mkdir()
        self.output_dir.mkdir()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir)

    def _touch(self, rel: str) -> Path:
        p = self.input_dir / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b"fLaC")
        return p

    def test_finds_lowercase_flac(self):
        self._touch("album/track.flac")
        scanner = Scanner(_make_config(self.input_dir, self.output_dir))
        results = list(scanner.scan())
        self.assertEqual(len(results), 1)

    def test_finds_uppercase_flac(self):
        self._touch("album/TRACK.FLAC")
        scanner = Scanner(_make_config(self.input_dir, self.output_dir))
        results = list(scanner.scan())
        self.assertEqual(len(results), 1)

    def test_finds_mixed_case_flac(self):
        self._touch("album/Song.Flac")
        scanner = Scanner(_make_config(self.input_dir, self.output_dir))
        results = list(scanner.scan())
        self.assertEqual(len(results), 1)

    def test_no_double_count_on_case_sensitive_fs(self):
        """Ensure we don't match both '*.flac' and '*.FLAC' on a
        case-sensitive filesystem and count files twice."""
        self._touch("album/one.flac")
        self._touch("album/two.flac")
        scanner = Scanner(_make_config(self.input_dir, self.output_dir))
        results = list(scanner.scan())
        self.assertEqual(len(results), 2)

    def test_ignores_non_flac_files(self):
        self._touch("album/notes.txt")
        self._touch("album/cover.jpg")
        self._touch("album/song.flac")
        scanner = Scanner(_make_config(self.input_dir, self.output_dir))
        results = list(scanner.scan())
        self.assertEqual(len(results), 1)

    def test_output_mirrors_input_structure(self):
        self._touch("Artist/Album/01 - Song.flac")
        scanner = Scanner(_make_config(self.input_dir, self.output_dir))
        src, dst = next(scanner.scan())
        self.assertEqual(
            dst,
            self.output_dir / "Artist" / "Album" / "01 - Song.m4a",
        )

    def test_skips_existing_output_by_default(self):
        self._touch("album/song.flac")
        # Create the matching output so it should be skipped
        out = self.output_dir / "album" / "song.m4a"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(b"")
        scanner = Scanner(_make_config(self.input_dir, self.output_dir))
        results = list(scanner.scan())
        self.assertEqual(len(results), 0)


if __name__ == "__main__":
    unittest.main()
