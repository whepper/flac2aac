"""Tests for config.py validation and loading."""

import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from config import (
    ConfigError,
    CoverFileConfig,
    EncodingConfig,
    LoudnessConfig,
    ProcessingConfig,
    load_config,
)


class TestEncodingConfig(unittest.TestCase):
    def test_valid_defaults(self):
        cfg = EncodingConfig()
        self.assertEqual(cfg.vbr_quality, 5)
        self.assertEqual(cfg.output_format, "m4a")

    def test_vbr_out_of_range_low(self):
        with self.assertRaises(ConfigError):
            EncodingConfig(vbr_quality=0)

    def test_vbr_out_of_range_high(self):
        with self.assertRaises(ConfigError):
            EncodingConfig(vbr_quality=6)

    def test_invalid_output_format(self):
        with self.assertRaises(ConfigError):
            EncodingConfig(output_format="ogg")


class TestCoverFileConfig(unittest.TestCase):
    def test_jpeg_quality_accepts_100(self):
        """The previous version capped at 95; now we allow Pillow's full range."""
        cfg = CoverFileConfig(jpeg_quality=100)
        self.assertEqual(cfg.jpeg_quality, 100)

    def test_jpeg_quality_zero_rejected(self):
        with self.assertRaises(ConfigError):
            CoverFileConfig(jpeg_quality=0)

    def test_negative_max_size_rejected(self):
        with self.assertRaises(ConfigError):
            CoverFileConfig(max_size=-1)


class TestLoudnessConfig(unittest.TestCase):
    def test_defaults_include_reuse_flag(self):
        cfg = LoudnessConfig()
        self.assertTrue(cfg.reuse_existing_replaygain)

    def test_reference_loudness_bounds(self):
        LoudnessConfig(reference_loudness=-18.0)  # OK
        with self.assertRaises(ConfigError):
            LoudnessConfig(reference_loudness=-40.0)
        with self.assertRaises(ConfigError):
            LoudnessConfig(reference_loudness=5.0)


class TestProcessingConfig(unittest.TestCase):
    def test_invalid_log_level(self):
        with self.assertRaises(ConfigError):
            ProcessingConfig(log_level="verbose")

    def test_log_level_normalised_to_upper(self):
        cfg = ProcessingConfig(log_level="debug")
        self.assertEqual(cfg.log_level, "DEBUG")

    def test_zero_workers_rejected(self):
        with self.assertRaises(ConfigError):
            ProcessingConfig(workers=0)


class TestLoadConfig(unittest.TestCase):
    def test_missing_file(self):
        with self.assertRaises(FileNotFoundError):
            load_config(Path("/nonexistent/config.toml"))

    def test_invalid_toml(self):
        with tempfile.NamedTemporaryFile(
            "w", suffix=".toml", delete=False
        ) as f:
            f.write("this is [not valid toml\n")
            path = Path(f.name)
        try:
            with self.assertRaises(ConfigError):
                load_config(path)
        finally:
            path.unlink()

    def test_unknown_key_rejected(self):
        """Typos in config options should produce a clear error."""
        with tempfile.NamedTemporaryFile(
            "w", suffix=".toml", delete=False
        ) as f:
            f.write(
                "[paths]\n"
                'input_dir = "/tmp/in"\n'
                'output_dir = "/tmp/out"\n'
                "\n[encoding]\n"
                "vrb_quality = 5\n"  # typo: vrb vs vbr
            )
            path = Path(f.name)
        try:
            with self.assertRaises(ConfigError):
                load_config(path)
        finally:
            path.unlink()

    def test_minimal_valid_config(self):
        with tempfile.NamedTemporaryFile(
            "w", suffix=".toml", delete=False
        ) as f:
            f.write(
                "[paths]\n"
                'input_dir = "/tmp/in"\n'
                'output_dir = "/tmp/out"\n'
            )
            path = Path(f.name)
        try:
            cfg = load_config(path)
            self.assertEqual(cfg.encoding.vbr_quality, 5)
            self.assertTrue(cfg.loudness.reuse_existing_replaygain)
        finally:
            path.unlink()


if __name__ == "__main__":
    unittest.main()
