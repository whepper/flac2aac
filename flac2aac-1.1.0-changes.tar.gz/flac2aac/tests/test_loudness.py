"""Tests for ReplayGain ↔ iTunNORM conversion in loudness.py.

Reference values come from Mp3tag's ``$rg2sc`` function, which uses the
formula ``round(1000 * 10 ^ (-gain_db / 10))``. See:
https://community.mp3tag.de/t/updating-itunes-soundcheck/47702
"""

import os
import sys
import unittest
from unittest.mock import MagicMock

# Allow "python -m pytest tests/" to find modules at the repo root
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from loudness import ITUNNORM_MAX, LoudnessProcessor


def _make_processor() -> LoudnessProcessor:
    """Build a LoudnessProcessor without touching the real Config class."""
    fake_config = MagicMock()
    fake_config.loudness.reference_loudness = -18.0
    fake_config.loudness.enable_replaygain = True
    fake_config.loudness.enable_itunes_soundcheck = True
    fake_config.loudness.reuse_existing_replaygain = True
    return LoudnessProcessor(fake_config)


class TestReplayGainToSoundcheck(unittest.TestCase):
    """Verify the iTunNORM conversion matches Mp3tag's $rg2sc output."""

    def setUp(self):
        self.processor = _make_processor()

    def test_format_is_10_hex_values_with_leading_space(self):
        result = self.processor._replaygain_to_soundcheck(-5.91)
        # Leading space, then 10 hex tokens
        self.assertTrue(result.startswith(" "))
        tokens = result.strip().split(" ")
        self.assertEqual(len(tokens), 10)
        for token in tokens:
            self.assertEqual(len(token), 8)
            # Must be valid uppercase hex
            int(token, 16)
            self.assertEqual(token.upper(), token)

    def test_all_ten_values_are_identical(self):
        """Mp3tag / fb2k repeat the same value in all ten slots."""
        result = self.processor._replaygain_to_soundcheck(-7.23)
        tokens = result.strip().split(" ")
        self.assertEqual(len(set(tokens)), 1)

    def test_zero_gain_is_reference(self):
        """At 0 dB, the value must be exactly 1000 (0x3E8)."""
        result = self.processor._replaygain_to_soundcheck(0.0)
        tokens = result.strip().split(" ")
        self.assertEqual(int(tokens[0], 16), 1000)

    def test_known_value_minus_591_db(self):
        """-5.91 dB → 0x00000F3B (from Mp3tag reference output)."""
        result = self.processor._replaygain_to_soundcheck(-5.91)
        tokens = result.strip().split(" ")
        # Reference:
        # " 00000F3B 00000F3B 00000F3B 00000F3B 00000F3B 00000F3B
        #   00000F3B 00000F3B 00000F3B 00000F3B"
        self.assertEqual(tokens[0], "00000F3B")

    def test_known_value_minus_723_db(self):
        """Spot-check -7.23 dB against hand-computed value."""
        # 1000 * 10^(7.23/10) ≈ 5284.44 → 5284 → 0x000014A4
        result = self.processor._replaygain_to_soundcheck(-7.23)
        tokens = result.strip().split(" ")
        self.assertEqual(int(tokens[0], 16), 5284)

    def test_positive_gain_produces_smaller_value(self):
        """A positive ReplayGain means the track is *quiet* — sc < 1000."""
        result = self.processor._replaygain_to_soundcheck(+3.0)
        tokens = result.strip().split(" ")
        value = int(tokens[0], 16)
        self.assertLess(value, 1000)
        self.assertGreater(value, 0)

    def test_extreme_negative_gain_is_clamped(self):
        """Very loud tracks (large negative gain) don't overflow."""
        # -40 dB would give 10,000,000 without clamping
        result = self.processor._replaygain_to_soundcheck(-40.0)
        tokens = result.strip().split(" ")
        value = int(tokens[0], 16)
        self.assertLessEqual(value, ITUNNORM_MAX)

    def test_extreme_positive_gain_is_non_negative(self):
        """Huge positive gain mustn't produce a negative/invalid value."""
        result = self.processor._replaygain_to_soundcheck(+60.0)
        tokens = result.strip().split(" ")
        value = int(tokens[0], 16)
        self.assertGreaterEqual(value, 0)

    def test_formula_matches_mp3tag(self):
        """Sample a range of ReplayGain values and compare against the
        canonical formula used by Mp3tag."""
        import math

        for gain_db in [-12.5, -6.0, -3.5, -1.0, 0.0, 0.5, 2.0, 5.0]:
            expected = int(round(1000 * (10 ** (-gain_db / 10.0))))
            expected = max(0, min(expected, ITUNNORM_MAX))

            result = self.processor._replaygain_to_soundcheck(gain_db)
            actual = int(result.strip().split(" ")[0], 16)
            self.assertEqual(
                actual, expected,
                f"gain={gain_db} dB: expected {expected}, got {actual}",
            )


if __name__ == "__main__":
    unittest.main()
