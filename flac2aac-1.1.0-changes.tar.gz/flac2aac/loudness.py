"""Loudness analysis and tagging module.

Handles ReplayGain 2.0 (EBU R128) and iTunes SoundCheck tag generation.
"""

import logging
from pathlib import Path
from typing import List, Optional

try:
    from mutagen.flac import FLAC
    from mutagen.mp4 import MP4, MP4FreeForm
except ImportError:
    raise ImportError(
        "mutagen package required. Install with: pip install mutagen"
    )

try:
    import r128gain
except ImportError:
    r128gain = None
    logging.warning(
        "r128gain not installed. ReplayGain tagging disabled. "
        "Install with: pip install r128gain"
    )

from config import Config

logger = logging.getLogger(__name__)


# iTunNORM maximum value. Values above this are clamped.
# iTunes stores each value as a 32-bit unsigned int in ASCII hex.
ITUNNORM_MAX = 0xFFFFFFFE


class LoudnessProcessor:
    """Handles loudness analysis and tag writing."""

    def __init__(self, config: Config):
        """Initialize loudness processor.

        Args:
            config: Application configuration
        """
        self.config = config
        self.loudness_config = config.loudness
        self.reference = self.loudness_config.reference_loudness

    def process_album(
        self,
        m4a_files: List[Path],
        flac_sources: Optional[List[Path]] = None,
    ) -> None:
        """Process loudness for an album.

        If ``flac_sources`` is given and every source already has
        ReplayGain tags, those values are copied to the M4A files instead
        of running a fresh analysis pass — significantly faster for
        libraries that are already tagged (e.g. with rsgain or metaflac).

        Args:
            m4a_files: List of M4A files in the album
            flac_sources: Matching source FLAC files (same order as m4a_files)
        """
        if not m4a_files:
            return

        logger.info(f"Processing loudness for {len(m4a_files)} track(s)")

        # Try to reuse ReplayGain tags from the source FLACs first
        reused = False
        if (
            self.loudness_config.enable_replaygain
            and self.loudness_config.reuse_existing_replaygain
            and flac_sources
            and len(flac_sources) == len(m4a_files)
        ):
            reused = self._copy_replaygain_from_flac(flac_sources, m4a_files)
            if reused:
                logger.info(
                    f"Reused existing ReplayGain tags from source FLACs "
                    f"for {len(m4a_files)} file(s)"
                )

        # Otherwise compute ReplayGain fresh
        if self.loudness_config.enable_replaygain and not reused:
            if r128gain is None:
                logger.warning("r128gain not available, skipping ReplayGain")
            else:
                self._add_replaygain_tags(m4a_files)

        # Add iTunes SoundCheck if enabled
        if self.loudness_config.enable_itunes_soundcheck:
            self._add_itunes_soundcheck(m4a_files)

    # ------------------------------------------------------------------
    # ReplayGain
    # ------------------------------------------------------------------

    def _copy_replaygain_from_flac(
        self, flac_sources: List[Path], m4a_files: List[Path]
    ) -> bool:
        """Copy ReplayGain tags from source FLACs to M4A files.

        Returns True if every source had complete ReplayGain data and all
        tags were copied; False otherwise (in which case the caller should
        fall back to running fresh analysis).
        """
        rg_keys = (
            "replaygain_track_gain",
            "replaygain_track_peak",
            "replaygain_album_gain",
            "replaygain_album_peak",
        )

        # Collect values from all sources first. Require track gain + peak
        # at minimum; album gain + peak are nice-to-have.
        per_file = []
        for flac_path in flac_sources:
            try:
                flac = FLAC(flac_path)
            except Exception as exc:
                logger.debug(f"Cannot read {flac_path.name}: {exc}")
                return False
            values = {k: flac.get(k, [None])[0] for k in rg_keys}
            if not values["replaygain_track_gain"] or not values["replaygain_track_peak"]:
                logger.debug(
                    f"{flac_path.name} lacks ReplayGain tags; "
                    "falling back to fresh analysis"
                )
                return False
            per_file.append(values)

        # Write the values to the M4A files
        for m4a_path, values in zip(m4a_files, per_file):
            try:
                m4a = MP4(m4a_path)
                for key, val in values.items():
                    if val is None:
                        continue
                    m4a_key = f"----:com.apple.iTunes:{key.upper()}"
                    m4a[m4a_key] = [MP4FreeForm(str(val).encode("utf-8"))]
                m4a.save()
            except Exception as exc:
                logger.warning(
                    f"Failed to copy ReplayGain to {m4a_path.name}: {exc}"
                )
                return False

        return True

    def _add_replaygain_tags(self, m4a_files: List[Path]) -> None:
        """Add ReplayGain 2.0 tags using r128gain.

        Note: r128gain uses a fixed reference of -18 LUFS (ReplayGain 2.0
        standard). The reference_loudness config option is only used for
        iTunNORM calculation.
        """
        try:
            file_paths = [str(f) for f in m4a_files]

            logger.debug(f"Running R128 analysis on {len(file_paths)} file(s)")

            r128gain.process(
                file_paths,
                album_gain=True,
                skip_tagged=False,
                opus_output_gain=False,
            )

            logger.info(f"Added ReplayGain tags to {len(m4a_files)} file(s)")

        except Exception as e:
            logger.error(f"Failed to add ReplayGain tags: {e}")

    # ------------------------------------------------------------------
    # iTunNORM
    # ------------------------------------------------------------------

    def _add_itunes_soundcheck(self, m4a_files: List[Path]) -> None:
        """Add iTunes SoundCheck (iTunNORM) tags based on ReplayGain."""
        for m4a_file in m4a_files:
            try:
                m4a = MP4(m4a_file)

                # Look for ReplayGain in the canonical freeform key plus a
                # few common variants.
                rg_gain = None
                for key in (
                    "----:com.apple.iTunes:REPLAYGAIN_TRACK_GAIN",
                    "----:com.apple.iTunes:replaygain_track_gain",
                    "----:com.apple.iTunes:REPLAYGAIN_ALBUM_GAIN",
                ):
                    if key in m4a:
                        rg_gain = self._get_replaygain_value(m4a, key)
                        if rg_gain is not None:
                            logger.debug(
                                f"Using gain from '{key}' for {m4a_file.name}: "
                                f"{rg_gain} dB"
                            )
                            break

                if rg_gain is None:
                    logger.warning(
                        f"No ReplayGain data found for {m4a_file.name}, "
                        "skipping iTunNORM"
                    )
                    continue

                itunnorm = self._replaygain_to_soundcheck(rg_gain)
                m4a["----:com.apple.iTunes:iTunNORM"] = [
                    MP4FreeForm(itunnorm.encode("utf-8"))
                ]
                m4a.save()

                logger.info(
                    f"Added iTunNORM to {m4a_file.name} (gain: {rg_gain:.2f} dB)"
                )

            except Exception as e:
                logger.error(f"Failed to add iTunNORM to {m4a_file.name}: {e}")

    def _get_replaygain_value(self, m4a: MP4, key: str) -> Optional[float]:
        """Extract a ReplayGain dB value from an M4A freeform tag."""
        if key not in m4a:
            return None

        try:
            value = m4a[key][0]

            if isinstance(value, MP4FreeForm):
                value_bytes = bytes(value)
            elif isinstance(value, bytes):
                value_bytes = value
            else:
                value_bytes = str(value).encode("utf-8")

            value_str = value_bytes.decode("utf-8").strip()

            # Tolerate "-7.23 dB", "+1.5dB", "-7.23"
            gain_str = value_str.replace("dB", "").strip()
            return float(gain_str)

        except (ValueError, IndexError, AttributeError, UnicodeDecodeError) as e:
            logger.warning(f"Failed to parse ReplayGain value from {key}: {e}")
            return None

    def _replaygain_to_soundcheck(self, gain_db: float) -> str:
        """Convert ReplayGain dB to iTunes SoundCheck (iTunNORM) format.

        Uses the widely-adopted Mp3tag / foobar2000 formula:

            sc = round(1000 * 10 ^ (-gain_db / 10))

        The value is a 32-bit unsigned integer, formatted as an
        8-character uppercase hex string, and repeated across all ten
        iTunNORM slots. This matches the output of Mp3tag's ``$rg2sc``
        function and is accepted by iTunes, Apple Music, Sonos and other
        SoundCheck-compatible players.

        Reference:
            https://community.mp3tag.de/t/updating-itunes-soundcheck/47702

        Args:
            gain_db: ReplayGain gain in dB

        Returns:
            iTunNORM string — 10 hex values separated by spaces, with a
            leading space (the format iTunes expects).
        """
        # 1000 is the reference value at 0 dB.
        sc_value = int(round(1000 * (10 ** (-gain_db / 10.0))))

        # Clamp to the valid range: [0, 0xFFFFFFFE]
        sc_value = max(0, min(sc_value, ITUNNORM_MAX))

        hex_value = f"{sc_value:08X}"

        # iTunNORM is 10 space-separated hex values with a leading space.
        # Mp3tag and fb2k produce the same value in all ten slots.
        return " " + " ".join([hex_value] * 10)
