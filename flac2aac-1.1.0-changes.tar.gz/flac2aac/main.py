#!/usr/bin/env python3
"""FLAC to AAC Converter - Entry Point

A Python application that converts FLAC files to AAC format using FDK-AAC
at the highest VBR quality, preserving metadata and adding loudness tags.
"""

import argparse
import logging
import sys
from pathlib import Path

from config import ConfigError, load_config
from pipeline import Pipeline

try:
    from importlib.metadata import PackageNotFoundError, version as _pkg_version
    try:
        __version__ = _pkg_version("flac2aac")
    except PackageNotFoundError:
        __version__ = "1.1.0"
except ImportError:
    __version__ = "1.1.0"


def setup_logging(level: str) -> None:
    """Configure application logging.

    Reconfigures the root logger even if it was already set up (e.g. by
    the bootstrap logger below), so that log_level from the config file
    takes effect.
    """
    numeric_level = getattr(logging, level.upper(), logging.INFO)
    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)
    logging.basicConfig(
        level=numeric_level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def _bootstrap_logging() -> None:
    """Minimal logging setup used before we've loaded the config."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s - %(message)s",
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="flac2aac",
        description=(
            "Convert FLAC files to AAC with metadata preservation, "
            "ReplayGain 2.0 and iTunes SoundCheck tagging."
        ),
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("config.toml"),
        help="Path to configuration file (default: config.toml)",
    )
    parser.add_argument(
        "--input",
        type=Path,
        help="Override input_dir from the config file",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Override output_dir from the config file",
    )
    parser.add_argument(
        "--workers",
        type=int,
        help="Override processing.workers from the config file",
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Override processing.log_level from the config file",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Scan and report without encoding",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def _apply_overrides(config, args: argparse.Namespace) -> None:
    """Apply CLI overrides onto an already-loaded Config object."""
    if args.input:
        config.paths.input_dir = Path(args.input).expanduser().resolve()
    if args.output:
        config.paths.output_dir = Path(args.output).expanduser().resolve()
    if args.workers is not None:
        if args.workers < 1:
            raise ConfigError("--workers must be >= 1")
        config.processing.workers = args.workers
    if args.log_level:
        config.processing.log_level = args.log_level


def main() -> int:
    """Main entry point. Returns the exit code."""
    _bootstrap_logging()

    parser = _build_parser()
    args = parser.parse_args()

    # Load configuration with distinct error paths
    try:
        config = load_config(args.config)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except ConfigError as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        return 2

    try:
        _apply_overrides(config, args)
    except ConfigError as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        return 2

    setup_logging(config.processing.log_level)
    logger = logging.getLogger(__name__)

    logger.info(f"flac2aac {__version__} starting")
    logger.info(f"Input: {config.paths.input_dir}")
    logger.info(f"Output: {config.paths.output_dir}")
    logger.info(f"Workers: {config.processing.workers}")

    try:
        pipeline = Pipeline(config, dry_run=args.dry_run)
        stats = pipeline.run()

        logger.info("\n" + "=" * 60)
        logger.info("Conversion Summary")
        logger.info("=" * 60)
        logger.info(f"Total files processed: {stats.total_files}")
        logger.info(f"Successful: {stats.successful}")
        logger.info(f"Failed: {stats.failed}")
        logger.info(f"Skipped: {stats.skipped}")
        logger.info(f"Albums processed: {stats.albums_processed}")
        logger.info("=" * 60)

        return 0 if stats.failed == 0 else 1

    except KeyboardInterrupt:
        logger.warning("\nOperation cancelled by user")
        return 130
    except Exception as e:
        logger.exception(f"Fatal error: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
