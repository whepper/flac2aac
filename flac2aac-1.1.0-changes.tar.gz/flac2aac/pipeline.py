"""Main processing pipeline orchestrator.

Coordinates scanning, encoding, metadata copying, and loudness tagging.

When a work_dir is configured, all processing is done there first and
finished albums are moved to output_dir in a single operation, minimising
writes to the final storage device (ideal for RAM disk workflows).
"""

import logging
import shutil
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

from config import Config
from encoder import Encoder, EncodingError
from loudness import LoudnessProcessor
from metadata import CoverManager, MetadataHandler
from scanner import Scanner

logger = logging.getLogger(__name__)


@dataclass
class ProcessingStats:
    """Statistics for processing run."""

    total_files: int = 0
    successful: int = 0
    failed: int = 0
    skipped: int = 0
    albums_processed: int = 0


class Pipeline:
    """Main processing pipeline.

    Threading note: the encoder step runs in a ThreadPoolExecutor. This is
    safe even though encoding is CPU-bound because FFmpeg is launched as a
    separate subprocess per task — the Python GIL isn't held during the
    real work. The mutagen tag-copy that follows encoding is I/O bound.
    """

    def __init__(self, config: Config, dry_run: bool = False):
        """Initialize pipeline.

        Args:
            config: Application configuration
            dry_run: If True, only scan and report without processing
        """
        self.config = config
        self.dry_run = dry_run
        self.use_work_dir = config.paths.work_dir is not None

        # Initialize components
        self.scanner = Scanner(config)
        self.encoder = Encoder(config)
        self.metadata_handler = MetadataHandler(config)
        self.cover_manager = CoverManager(config)
        self.loudness_processor = LoudnessProcessor(config)

        self.stats = ProcessingStats()

    def run(self) -> ProcessingStats:
        """Run the complete pipeline."""
        if not self.dry_run and not self.encoder.verify_ffmpeg():
            raise RuntimeError("FFmpeg with libfdk_aac not available")

        logger.info("Scanning for FLAC files...")
        # Deduplicate by destination path — the scanner should never yield
        # duplicates, but this protects against aliasing via symlinks.
        seen_dests: set = set()
        file_pairs: List[Tuple[Path, Path]] = []
        for source, dest in self.scanner.scan():
            if dest in seen_dests:
                logger.debug(f"Skipping duplicate destination: {dest}")
                continue
            seen_dests.add(dest)
            file_pairs.append((source, dest))

        if not file_pairs:
            logger.warning("No FLAC files found to process")
            return self.stats

        self.stats.total_files = len(file_pairs)
        logger.info(f"Found {self.stats.total_files} file(s) to process")

        if self.use_work_dir:
            logger.info(f"Working directory: {self.config.paths.work_dir}")
        else:
            logger.info(
                "Working directory: disabled (writing directly to output)"
            )

        if self.dry_run:
            self._print_dry_run_report(file_pairs)
            return self.stats

        album_groups = self._group_by_album(file_pairs)
        logger.info(f"Organised into {len(album_groups)} album(s)")

        for album_dir, files in album_groups.items():
            logger.info(f"\nProcessing album: {album_dir}")
            try:
                self._process_album(files)
            except Exception as exc:
                logger.error(f"Album failed: {album_dir}: {exc}")
                # Continue with the next album rather than bailing out of
                # the whole run.
                continue
            self.stats.albums_processed += 1

        return self.stats

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _group_by_album(
        self, file_pairs: List[Tuple[Path, Path]]
    ) -> Dict[Path, List[Tuple[Path, Path]]]:
        """Group file pairs by source album directory."""
        groups: Dict[Path, List[Tuple[Path, Path]]] = defaultdict(list)
        for source, dest in file_pairs:
            groups[self.scanner.get_album_dir(source)].append((source, dest))
        return dict(groups)

    def _process_album(self, file_pairs: List[Tuple[Path, Path]]) -> None:
        """Process all files in one album."""
        source_album_dir = self.scanner.get_album_dir(file_pairs[0][0])
        final_album_dir = self.scanner.get_album_dir(file_pairs[0][1])

        if self.use_work_dir:
            work_album_dir = self._make_work_album_dir(final_album_dir)
            logger.info(f"  Work directory: {work_album_dir}")
        else:
            work_album_dir = final_album_dir

        try:
            # Phase 1 & 2: Encode + copy metadata (parallel)
            logger.info(f"  Encoding {len(file_pairs)} track(s)...")
            work_dest_files, flac_sources = self._encode_album(
                file_pairs, work_album_dir
            )

            if not work_dest_files:
                logger.warning("  No files successfully encoded in this album")
                return

            # Warn if the album is partially encoded — album gain will be
            # calculated from the incomplete set.
            if len(work_dest_files) < len(file_pairs):
                logger.warning(
                    f"  Album is partially encoded "
                    f"({len(work_dest_files)}/{len(file_pairs)} tracks); "
                    "album gain will reflect only the successful tracks"
                )

            # Phase 3: Cover art
            logger.info("  Processing cover art...")
            self.cover_manager.handle_cover_file(source_album_dir, work_album_dir)

            # Phase 4 & 5: Loudness analysis + iTunNORM
            logger.info("  Analysing loudness and adding tags...")
            self.loudness_processor.process_album(work_dest_files, flac_sources)

            # Phase 6: Move finished album to output_dir
            if self.use_work_dir:
                self._move_album_to_output(work_album_dir, final_album_dir)

        except Exception:
            # On failure clean up the work directory so no half-finished
            # files are left behind on the RAM disk.
            if self.use_work_dir and work_album_dir.exists():
                logger.warning(
                    f"  Cleaning up work directory after error: {work_album_dir}"
                )
                shutil.rmtree(work_album_dir, ignore_errors=True)
            raise

    def _encode_album(
        self,
        file_pairs: List[Tuple[Path, Path]],
        work_album_dir: Path,
    ) -> Tuple[List[Path], List[Path]]:
        """Encode all tracks for one album into ``work_album_dir``.

        Returns:
            (work_dest_files, flac_sources) — parallel lists of the
            successfully encoded M4A destinations and their matching
            FLAC sources, in stable sorted order.
        """
        # Remap destination paths to work directory
        work_file_pairs: List[Tuple[Path, Path]] = []
        for source, _final_dest in file_pairs:
            out_name = source.with_suffix(
                f".{self.config.encoding.output_format}"
            ).name
            work_dest = work_album_dir / out_name
            work_file_pairs.append((source, work_dest))

        # Track (source, dest) for successful encodes so we can keep them
        # ordered identically when calling loudness.
        successes: List[Tuple[Path, Path]] = []

        with ThreadPoolExecutor(
            max_workers=self.config.processing.workers
        ) as executor:
            futures = {
                executor.submit(self._encode_file, src, dst): (src, dst)
                for src, dst in work_file_pairs
            }
            for future in as_completed(futures):
                src, dst = futures[future]
                try:
                    if future.result():
                        successes.append((src, dst))
                        self.stats.successful += 1
                    else:
                        self.stats.failed += 1
                except Exception as exc:
                    logger.error(
                        f"  Unexpected error processing {src.name}: {exc}"
                    )
                    self.stats.failed += 1

        successes.sort(key=lambda pair: pair[1].name)
        flac_sources = [s for s, _ in successes]
        work_dest_files = [d for _, d in successes]
        return work_dest_files, flac_sources

    def _encode_file(self, source: Path, dest: Path) -> bool:
        """Encode a single file and copy its metadata. Returns True on success."""
        try:
            self.encoder.encode(source, dest)
            self.metadata_handler.copy_metadata(source, dest)
            return True
        except EncodingError as exc:
            logger.error(f"  Encoding failed for {source.name}: {exc}")
            return False
        except Exception as exc:
            logger.error(f"  Failed to process {source.name}: {exc}")
            return False

    def _make_work_album_dir(self, final_album_dir: Path) -> Path:
        """Create a uniquely named album directory inside ``work_dir``."""
        relative = final_album_dir.relative_to(self.config.paths.output_dir)
        work_album_dir = self.config.paths.work_dir / relative
        work_album_dir.mkdir(parents=True, exist_ok=True)
        return work_album_dir

    def _move_album_to_output(
        self, work_album_dir: Path, final_album_dir: Path
    ) -> None:
        """Move a completed album from ``work_dir`` to ``output_dir``.

        Copies each file from the work dir to the output dir individually.
        ``shutil.move`` handles the cross-filesystem case (RAM disk →
        output) by falling back to copy + delete.
        """
        final_album_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"  Moving album to output: {final_album_dir}")

        for work_file in work_album_dir.iterdir():
            dest_file = final_album_dir / work_file.name
            if dest_file.exists():
                dest_file.unlink()
            shutil.move(str(work_file), str(dest_file))
            logger.debug(f"    Moved: {work_file.name}")

        # Clean up the now-empty work album directory, and its parent
        # chain up to (but not including) work_dir itself, if empty.
        try:
            work_album_dir.rmdir()
            parent = work_album_dir.parent
            work_root = self.config.paths.work_dir
            while parent != work_root and parent.is_relative_to(work_root):
                try:
                    parent.rmdir()
                except OSError:
                    break
                parent = parent.parent
        except OSError:
            logger.debug(
                f"  Could not remove work dir (not empty): {work_album_dir}"
            )

    def _print_dry_run_report(self, file_pairs: List[Tuple[Path, Path]]) -> None:
        """Print dry-run report."""
        logger.info("\n" + "=" * 60)
        logger.info("DRY RUN - Files to be processed:")
        logger.info("=" * 60)
        for source, dest in file_pairs:
            logger.info(f"  {source}")
            logger.info(f"  -> {dest}\n")
        logger.info("=" * 60)
        logger.info(f"Total: {len(file_pairs)} file(s)")
        logger.info("=" * 60)
