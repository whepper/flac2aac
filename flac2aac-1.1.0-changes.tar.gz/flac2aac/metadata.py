"""Metadata handling module for FLAC and M4A files.

Handles tag mapping, cover art extraction and embedding.
"""

import logging
import shutil
import tempfile
from pathlib import Path
from typing import Optional

try:
    from mutagen.flac import FLAC
    from mutagen.mp4 import MP4, MP4Cover
except ImportError:
    raise ImportError(
        "mutagen package required. Install with: pip install mutagen"
    )

try:
    from PIL import Image
except ImportError:
    Image = None
    logging.warning("Pillow not installed. Cover resize/convert disabled.")

from config import Config

logger = logging.getLogger(__name__)

# Vorbis Comment → MP4 atom mapping for standard tags.
#
# Note on date/year: Vorbis has both ``date`` (full ISO) and ``year``
# (year only). When both are present we prefer ``date``; see _copy_text_tags.
TAG_MAPPING = {
    "title": "©nam",
    "artist": "©ART",
    "albumartist": "aART",
    "album": "©alb",
    "date": "©day",
    "year": "©day",
    "tracknumber": "trkn",
    "discnumber": "disk",
    "genre": "©gen",
    "comment": "©cmt",
    "composer": "©wrt",
    "lyrics": "©lyr",
    "copyright": "cprt",
    "bpm": "tmpo",
    "grouping": "©grp",
    "compilation": "cpil",
}

# Vorbis tags written through as MP4 freeform (``----``) atoms. These are
# the tags audiophile libraries commonly carry that have no standard MP4
# equivalent. Uppercased in the freeform key to match the convention used
# by foobar2000 / beets / r128gain.
FREEFORM_PASSTHROUGH = (
    "isrc",
    "barcode",
    "catalognumber",
    "label",
    "originaldate",
    "originalyear",
    "musicbrainz_trackid",
    "musicbrainz_releasetrackid",
    "musicbrainz_albumid",
    "musicbrainz_artistid",
    "musicbrainz_albumartistid",
    "musicbrainz_releasegroupid",
    "musicbrainz_workid",
    "acoustid_id",
    "asin",
    "discsubtitle",
    "artists",
    "media",
    "script",
    "work",
)


class MetadataHandler:
    """Handles metadata transfer between FLAC and M4A."""

    def __init__(self, config: Config):
        """Initialize metadata handler."""
        self.config = config

    def copy_metadata(self, source: Path, destination: Path) -> None:
        """Copy metadata from a FLAC to an M4A file.

        Args:
            source: Source FLAC file
            destination: Destination M4A file
        """
        try:
            flac = FLAC(source)
            m4a = MP4(destination)

            self._copy_text_tags(flac, m4a)
            self._copy_freeform_tags(flac, m4a)

            if self.config.metadata.copy_artwork:
                self._copy_cover_art(flac, m4a)

            m4a.save()
            logger.debug(f"Copied metadata: {source.name} -> {destination.name}")

        except Exception as e:
            logger.error(f"Failed to copy metadata from {source.name}: {e}")
            raise

    # ------------------------------------------------------------------
    # Text tags
    # ------------------------------------------------------------------

    def _copy_text_tags(self, flac: FLAC, m4a: MP4) -> None:
        """Copy text tags from FLAC to M4A.

        Handles a few subtleties:

        * ``date`` wins over ``year`` when both are present (more precise).
        * track/disc totals come from ``tracktotal`` / ``totaltracks`` /
          ``disctotal`` / ``totaldiscs`` if the number itself doesn't
          embed a "N/T" denominator.
        * ``aART`` (album artist) falls back to ``artist`` when missing,
          so players that browse by album artist don't show "Unknown".
        """
        # Handle the date/year precedence explicitly before the main loop
        day_value = None
        if flac.get("date"):
            day_value = str(flac["date"][0])
        elif flac.get("year"):
            day_value = str(flac["year"][0])
        if day_value:
            m4a["©day"] = [day_value]

        # Handle track/disc separately so we can pick up totals
        for vorbis_key, mp4_key, total_keys in (
            ("tracknumber", "trkn", ("tracktotal", "totaltracks")),
            ("discnumber", "disk", ("disctotal", "totaldiscs")),
        ):
            values = flac.get(vorbis_key, [])
            if not values:
                continue
            try:
                parts = str(values[0]).split("/")
                number = int(parts[0])
                total = int(parts[1]) if len(parts) > 1 else 0
                if total == 0:
                    for tk in total_keys:
                        tv = flac.get(tk)
                        if tv:
                            total = int(str(tv[0]))
                            break
                m4a[mp4_key] = [(number, total)]
            except (ValueError, IndexError):
                logger.warning(f"Invalid {vorbis_key} format: {values[0]}")

        # Main text tag loop. Skip keys we handled above.
        skip = {"date", "year", "tracknumber", "discnumber"}
        for vorbis_key, mp4_key in TAG_MAPPING.items():
            if vorbis_key in skip:
                continue
            values = flac.get(vorbis_key, [])
            if not values:
                continue

            if mp4_key == "cpil":
                # compilation is a boolean
                m4a[mp4_key] = str(values[0]).strip().lower() in (
                    "1", "true", "yes",
                )
            elif mp4_key == "tmpo":
                try:
                    m4a[mp4_key] = [int(float(values[0]))]
                except (ValueError, TypeError):
                    logger.debug(f"Invalid BPM: {values[0]}")
            else:
                m4a[mp4_key] = [str(v) for v in values]

        # Fallback: use artist as album artist when missing
        if "aART" not in m4a and "©ART" in m4a:
            m4a["aART"] = list(m4a["©ART"])

    # ------------------------------------------------------------------
    # Freeform tags
    # ------------------------------------------------------------------

    def _copy_freeform_tags(self, flac: FLAC, m4a: MP4) -> None:
        """Copy non-standard tags as MP4 freeform (``----``) atoms."""
        from mutagen.mp4 import MP4FreeForm

        for vorbis_key in FREEFORM_PASSTHROUGH:
            values = flac.get(vorbis_key, [])
            if not values:
                continue
            m4a_key = f"----:com.apple.iTunes:{vorbis_key.upper()}"
            m4a[m4a_key] = [
                MP4FreeForm(str(v).encode("utf-8")) for v in values
            ]

    # ------------------------------------------------------------------
    # Cover art
    # ------------------------------------------------------------------

    def _copy_cover_art(self, flac: FLAC, m4a: MP4) -> None:
        """Copy embedded cover art from FLAC to M4A."""
        if not flac.pictures:
            logger.debug("No embedded cover art found")
            return

        # Prefer front cover (type 3), else first picture
        cover = next((p for p in flac.pictures if p.type == 3), flac.pictures[0])

        if cover.mime == "image/jpeg":
            image_format = MP4Cover.FORMAT_JPEG
        elif cover.mime == "image/png":
            image_format = MP4Cover.FORMAT_PNG
        else:
            logger.warning(f"Unsupported cover format: {cover.mime}")
            return

        m4a["covr"] = [MP4Cover(cover.data, imageformat=image_format)]
        logger.debug(f"Copied cover art ({cover.mime})")


class CoverManager:
    """Manages standalone cover art files."""

    def __init__(self, config: Config):
        """Initialize cover manager."""
        self.config = config
        self.cover_config = config.metadata.cover_file

    def handle_cover_file(
        self, source_album_dir: Path, dest_album_dir: Path
    ) -> None:
        """Handle standalone cover file for an album.

        Args:
            source_album_dir: Source album directory (read-only)
            dest_album_dir: Destination album directory
        """
        if not self.cover_config.enabled:
            return

        # Search for existing cover file in the source
        cover_source = self._find_cover_file(source_album_dir)
        cleanup_temp: Optional[Path] = None

        if not cover_source:
            # Fall back: extract from first FLAC in the source.
            # IMPORTANT: never write into the read-only source tree —
            # extract to a system temp file instead.
            cover_source, cleanup_temp = self._extract_cover_from_flac(
                source_album_dir
            )

        try:
            if cover_source:
                self._copy_cover_file(cover_source, dest_album_dir)
        finally:
            if cleanup_temp and cleanup_temp.exists():
                try:
                    cleanup_temp.unlink()
                except OSError:
                    pass

    def _find_cover_file(self, directory: Path) -> Optional[Path]:
        """Search for a standalone cover file in ``directory``."""
        # Case-insensitive: match each search name against every entry.
        wanted = {name.lower() for name in self.cover_config.search_names}
        try:
            entries = list(directory.iterdir())
        except OSError:
            return None

        for entry in entries:
            if entry.is_file() and entry.name.lower() in wanted:
                logger.debug(f"Found cover file: {entry.name}")
                return entry
        return None

    def _extract_cover_from_flac(
        self, directory: Path
    ) -> tuple[Optional[Path], Optional[Path]]:
        """Extract cover from first FLAC in ``directory`` into a temp file.

        Returns:
            (cover_path, cleanup_path) — both None if nothing was found.
            ``cleanup_path`` points at the temp file the caller should
            delete when finished; it's the same as ``cover_path``.
        """
        # Case-insensitive .flac match
        flac_files = sorted(
            p for p in directory.iterdir()
            if p.is_file() and p.suffix.lower() == ".flac"
        )
        if not flac_files:
            return None, None

        try:
            flac = FLAC(flac_files[0])
            if not flac.pictures:
                return None, None

            cover = next(
                (p for p in flac.pictures if p.type == 3),
                flac.pictures[0],
            )

            # Pick the extension from mime type so downstream resize works
            ext = ".jpg" if cover.mime == "image/jpeg" else ".png"
            tmp = tempfile.NamedTemporaryFile(
                prefix="flac2aac_cover_", suffix=ext, delete=False
            )
            try:
                tmp.write(cover.data)
                tmp.flush()
            finally:
                tmp.close()

            temp_path = Path(tmp.name)
            logger.debug(
                f"Extracted cover from {flac_files[0].name} to {temp_path.name}"
            )
            return temp_path, temp_path

        except Exception as e:
            logger.warning(f"Failed to extract cover: {e}")
            return None, None

    def _copy_cover_file(self, source: Path, dest_dir: Path) -> None:
        """Copy and optionally process a cover file to ``dest_dir``."""
        dest_dir.mkdir(parents=True, exist_ok=True)
        # Always use the configured fallback name in the destination so
        # we don't leak temp filenames and so the output is predictable.
        dest_path = dest_dir / self.cover_config.fallback_name

        # Skip if exists and overwrite disabled
        if dest_path.exists() and not self.config.processing.overwrite_existing:
            logger.debug(f"Cover file already exists: {dest_path.name}")
            return

        if Image and (
            self.cover_config.max_size > 0 or source.suffix.lower() != ".jpg"
        ):
            self._process_and_save(source, dest_path)
        else:
            shutil.copy2(source, dest_path)

        logger.info(f"Copied cover: {dest_path.name}")

    def _process_and_save(self, source: Path, dest: Path) -> None:
        """Process image (resize, convert to JPEG) and save."""
        try:
            with Image.open(source) as img:
                # Flatten alpha on a white background
                if img.mode in ("RGBA", "LA", "P"):
                    background = Image.new("RGB", img.size, (255, 255, 255))
                    if img.mode == "P":
                        img = img.convert("RGBA")
                    mask = img.split()[-1] if img.mode in ("RGBA", "LA") else None
                    background.paste(img, mask=mask)
                    img = background
                elif img.mode != "RGB":
                    img = img.convert("RGB")

                if self.cover_config.max_size > 0:
                    img.thumbnail(
                        (
                            self.cover_config.max_size,
                            self.cover_config.max_size,
                        ),
                        Image.Resampling.LANCZOS,
                    )

                img.save(
                    dest,
                    "JPEG",
                    quality=self.cover_config.jpeg_quality,
                    optimize=True,
                )
        except Exception as e:
            logger.warning(f"Failed to process image, copying as-is: {e}")
            shutil.copy2(source, dest)
